<?php 
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "db_penjualan";

$conn = mysqli_connect($host, $user, $password, $database);
?>